#ifndef __DEMO_H
#define __DEMO_H
#define DEVICE_NAME "demo_led_device"
#endif
